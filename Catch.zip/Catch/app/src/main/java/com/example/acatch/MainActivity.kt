import com.yourpackagename.catchthefruits.GameView

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Find the custom GameView and the new restart button
        val gameView = findViewById<GameView>(R.id.gameView)
        val restartButton = findViewById<Button>(R.id.restartButton)

        // Set the button's click listener
        restartButton.setOnClickListener {
            // Tell the GameView to restart the game
            gameView.startGame()
        }
    }
}