package com.yourpackagename.catchthefruits

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.View
import java.util.concurrent.ConcurrentLinkedQueue
import kotlin.random.Random

// Represents a falling object (fruit or bomb)
data class FallingObject(var x: Float, var y: Float, val isFruit: Boolean, val paint: Paint)

// Represents the player's basket
data class Basket(var x: Float, var y: Float, val paint: Paint)

class GameView(context: Context, attrs: AttributeSet) : View(context, attrs) {

    private val basketPaint = Paint().apply { color = Color.BLUE }
    private val fruitPaint = Paint().apply { color = Color.GREEN }
    private val bombPaint = Paint().apply { color = Color.RED }
    private val textPaint = Paint().apply {
        color = Color.BLACK
        textSize = 60f
    }

    private var basket = Basket(0f, 0f, basketPaint)
    private val fallingObjects = ConcurrentLinkedQueue<FallingObject>()

    private var score = 0
    private var lives = 3
    private var isGameOver = false

    private var lastSpawnTime = System.currentTimeMillis()

    // New variables for the leveling system
    private var level = 1
    private var fallingSpeed = 10f

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)

        if (isGameOver) {
            canvas.drawColor(Color.LTGRAY)
            canvas.drawText("Game Over!", width / 2f - 150, height / 2f, textPaint)
            canvas.drawText("Score: $score", width / 2f - 100, height / 2f + 80, textPaint)
            return
        }

        canvas.drawColor(Color.WHITE)

        canvas.drawRect(basket.x, basket.y, basket.x + 200f, basket.y + 50f, basket.paint)

        for (obj in fallingObjects) {
            canvas.drawCircle(obj.x, obj.y, 30f, obj.paint)
        }

        canvas.drawText("Score: $score", 20f, 60f, textPaint)
        canvas.drawText("Lives: $lives", 20f, 120f, textPaint)

        // Display the current level
        canvas.drawText("Level: $level", 20f, 180f, textPaint)

        update()

        postInvalidateOnAnimation()
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        if (isGameOver) return false

        when (event.action) {
            MotionEvent.ACTION_MOVE -> {
                basket.x = event.x - 100f
                if (basket.x < 0) basket.x = 0f
                if (basket.x + 200f > width) basket.x = width.toFloat() - 200f
            }
        }
        return true
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        basket.x = (w / 2f) - 100f
        basket.y = h - 100f
    }

    private fun update() {
        if (System.currentTimeMillis() - lastSpawnTime > 1000) {
            spawnObject()
            lastSpawnTime = System.currentTimeMillis()
        }

        val iterator = fallingObjects.iterator()
        while (iterator.hasNext()) {
            val obj = iterator.next()
            obj.y += fallingSpeed // Use the dynamic speed here

            if (obj.y > height) {
                iterator.remove()
                if (obj.isFruit) lives--
            }

            if (obj.y > basket.y && obj.x > basket.x && obj.x < basket.x + 200f) {
                if (obj.isFruit) {
                    score++
                    checkLevelUp() // Check for level up after scoring
                } else {
                    lives--
                }
                iterator.remove()
            }
        }

        if (lives <= 0) {
            isGameOver = true
        }
    }

    // Checks the score and increases the speed if a new level is reached
    private fun checkLevelUp() {
        val newLevel = (score / 10) + 1
        if (newLevel > level) {
            level = newLevel
            fallingSpeed += 1f // Increase the falling speed
        }
    }

    private fun spawnObject() {
        val isFruit = Random.nextBoolean()
        val x = Random.nextFloat() * (width - 60) + 30
        val paint = if (isFruit) fruitPaint else bombPaint
        fallingObjects.add(FallingObject(x, 0f, isFruit, paint))
    }
}